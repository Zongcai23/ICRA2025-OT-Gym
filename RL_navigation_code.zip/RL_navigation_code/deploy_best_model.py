import torch
import numpy as np
from DQN_env import NewDDPGEnv, TransformListener
from DQN import DQN  # 确保导入正确的 DQN 类
import rospy

# 加载最优模型
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# 修改1: 将state_dim改为5，确保与训练时一致
state_dim = 5  # 状态空间维度
action_dim = 10  # 动作空间维度

# 修改2: 设置epsilon_start和epsilon_end为0.01，增加少量的探索行为
agent = DQN(state_dim, action_dim, learning_rate=0.0002, gamma=0.99, 
            epsilon_start=0.01, epsilon_end=0.01, epsilon_decay=1.0, 
            target_update=10, device=device)

# 加载最优模型权重
agent.q_net.load_state_dict(torch.load('/media/jerry/System/RL_Result/best_model_750.pth', map_location=device))

# 修改3: 切换模型到评估模式
agent.q_net.eval()  # 切换到评估模式

# 初始化 ROS 节点
rospy.init_node('dqn_deployment', anonymous=True)

# 创建 TransformListener 和 环境实例
csv_path = "/media/jerry/System/PythonImage/generate/smooth/smoothed_path.csv"
listener = TransformListener()
env = NewDDPGEnv(listener, csv_path)

# 部署过程
state = env.reset()
done = False
total_reward = 0
count = 0  # 添加计数器用于调试

while not done and not rospy.is_shutdown():
    action = agent.take_action(state)  # 使用最优模型选择动作
    next_state, reward, done, _ = env.step(action)  # 执行动作，更新状态

    # 修改4: 打印状态和动作，调试变化情况
    print(f"Step: {count}, State: {state}, Action: {action}, Reward: {reward}, Done: {done}")

    state = next_state  # 更新状态
    total_reward += reward
    count += 1  # 计数器递增

print(f"Total reward obtained: {total_reward}")

env.close()  # 在操作结束后关闭环境
