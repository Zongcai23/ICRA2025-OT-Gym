import torch 
import numpy as np
from DQN_env import NewDDPGEnv, TransformListener
from DQN import DQN  # Ensure proper import of the DQN class
import rospy

# Load the optimal model
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Set state_dim to 5 to match training
state_dim = 5  # State space dimension
action_dim = 10  # Action space dimension

# Set epsilon_start and epsilon_end to 0.01 to allow minimal exploration
agent = DQN(state_dim, action_dim, learning_rate=0.0002, gamma=0.99, 
            epsilon_start=0.01, epsilon_end=0.01, epsilon_decay=1.0, 
            target_update=10, device=device)

# Load optimal model weights
agent.q_net.load_state_dict(torch.load('/media/jerry/System/RL_Result/best_model_750.pth', map_location=device))

# Switch model to evaluation mode
agent.q_net.eval()  # Switch to evaluation mode

# Initialize ROS node
rospy.init_node('dqn_deployment', anonymous=True)

# Create TransformListener and environment instance
csv_path = "/media/jerry/System/PythonImage/generate/smooth/smoothed_path.csv"
listener = TransformListener()
env = NewDDPGEnv(listener, csv_path)

# Deployment process
state = env.reset()
done = False
total_reward = 0
count = 0  # Add counter for debugging

while not done and not rospy.is_shutdown():
    action = agent.take_action(state)  # Select action using the optimal model
    next_state, reward, done, _ = env.step(action)  # Execute action and update state

    # Print state and action for debugging
    print(f"Step: {count}, State: {state}, Action: {action}, Reward: {reward}, Done: {done}")

    state = next_state  # Update state
    total_reward += reward
    count += 1  # Increment counter

print(f"Total reward obtained: {total_reward}")

env.close()  # Close environment after operations
