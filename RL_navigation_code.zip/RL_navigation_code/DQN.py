import random
import numpy as np
import collections
from tqdm import tqdm
import torch
import torch.nn.functional as F
import matplotlib.pyplot as plt
from DQN_env import NewDDPGEnv, TransformListener  # import NewDDPGEnv and TransformListener
import rospy
import time
import matplotlib.pyplot as plt


class ReplayBuffer:
    ''' Experience replay buffer '''
    def __init__(self, capacity):
        self.buffer = collections.deque(maxlen=capacity)  # queue, first‑in‑first‑out

    def add(self, state, action, reward, next_state, done):  # add a transition to the buffer
        self.buffer.append((state, action, reward, next_state, done))

    def sample(self, batch_size):  # sample a batch of transitions
        transitions = random.sample(self.buffer, batch_size)
        state, action, reward, next_state, done = zip(*transitions)
        return np.array(state), action, reward, np.array(next_state), done

    def size(self):  # current number of stored transitions
        return len(self.buffer)


class FullyConnectedQnet(torch.nn.Module):
    ''' Fully‑connected network for approximating the Q‑value function '''
    def __init__(self, state_dim, action_dim):
        super(FullyConnectedQnet, self).__init__()
        self.fc1 = torch.nn.Linear(state_dim, 128)
        self.fc2 = torch.nn.Linear(128, 128)
        self.head = torch.nn.Linear(128, action_dim)

    def forward(self, x):
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        return self.head(x)


class DQN:
    ''' DQN algorithm '''
    def __init__(self, state_dim, action_dim, learning_rate, gamma,
                 epsilon_start, epsilon_end, epsilon_decay, target_update, device):
        self.action_dim = action_dim
        self.q_net = FullyConnectedQnet(state_dim, self.action_dim).to(device)      # Q network
        self.target_q_net = FullyConnectedQnet(state_dim, self.action_dim).to(device)  # target network
        self.optimizer = torch.optim.Adam(self.q_net.parameters(), lr=learning_rate)   # Adam optimizer
        self.gamma = gamma                          # discount factor
        self.epsilon = epsilon_start                # initial epsilon
        self.epsilon_end = epsilon_end              # minimum epsilon
        self.epsilon_decay = epsilon_decay          # epsilon decay rate
        self.target_update = target_update          # how often to update target network
        self.count = 0                              # counter for target updates
        self.device = device

    def take_action(self, state):
        if np.random.random() < self.epsilon:
            action = np.random.randint(self.action_dim)
        else:
            state_tensor = torch.tensor([state], dtype=torch.float).to(self.device)
            action = self.q_net(state_tensor).argmax().item()
        return action

    def update(self, transition_dict):
        states = torch.tensor(transition_dict['states'], dtype=torch.float).to(self.device)
        actions = torch.tensor(transition_dict['actions']).view(-1, 1).to(self.device)
        rewards = torch.tensor(transition_dict['rewards'], dtype=torch.float).view(-1, 1).to(self.device)
        next_states = torch.tensor(transition_dict['next_states'], dtype=torch.float).to(self.device)
        dones = torch.tensor(transition_dict['dones'], dtype=torch.float).view(-1, 1).to(self.device)

        q_values = self.q_net(states).gather(1, actions)                      # Q(s, a)
        max_next_q_values = self.target_q_net(next_states).max(1)[0].view(-1, 1)  # max_a′ Q_target(s′, a′)
        q_targets = rewards + self.gamma * max_next_q_values * (1 - dones)    # TD target
        dqn_loss = torch.mean(F.mse_loss(q_values, q_targets))                # mean‑squared‑error loss
        self.optimizer.zero_grad()        # PyTorch accumulates gradients by default—set them to zero
        dqn_loss.backward()               # back‑propagate
        self.optimizer.step()

        if self.count % self.target_update == 0:
            self.target_q_net.load_state_dict(self.q_net.state_dict())        # sync target network
        self.count += 1

    def decay_epsilon(self):
        if self.epsilon > self.epsilon_end:
            self.epsilon *= self.epsilon_decay
        else:
            self.epsilon = self.epsilon_end


if __name__ == '__main__':
    rospy.init_node('dqn_training', anonymous=True)
    lr = 0.000065
    num_episodes = 5000
    gamma = 0.99
    epsilon_start = 0.5
    epsilon_end = 0.05
    epsilon_decay = 0.99
    target_update = 40
    buffer_size = 20000
    minimal_size = 128
    batch_size = 32
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    csv_path = "/media/jerry/System/PythonImage/generate/smooth/smoothed_path.csv"
    listener = TransformListener()
    env = NewDDPGEnv(listener, csv_path)
    random.seed(0)
    np.random.seed(0)
    torch.manual_seed(0)
    replay_buffer = ReplayBuffer(buffer_size)
    # state_dim = 8  # original five‑dimensional state space
    state_dim = 5   # revised state dimension
    action_dim = 10  # 10 discrete throttle levels
    agent = DQN(state_dim, action_dim, lr, gamma, epsilon_start,
                epsilon_end, epsilon_decay, target_update, device)

    return_list = []
    highest_return = -float('inf')
    lowest_return = float('inf')  # track lowest return as well
    best_model_path = "/media/jerry/System/RL_Result/best_model.pth"
    worst_model_path = "/media/jerry/System/RL_Result/worst_model.pth"
    for i in range(125):
        with tqdm(total=int(num_episodes / 125), desc='Iteration %d' % i) as pbar:
            # reset the best and worst return for each 250‑episode interval
            interval_best_return = -float('inf')
            interval_worst_return = float('inf')

            for i_episode in range(int(num_episodes / 125)):
                count = 0
                episode_return = 0
                state = env.reset()
                done = False
                info = True
                # while not done and info and count < 1000:
                while not done and count < 1000:
                    count += 1
                    action = agent.take_action(state)
                    next_state, reward, done, info = env.step(action)
                    replay_buffer.add(state, action, reward, next_state, done)

                    state = next_state
                    episode_return += reward

                    if replay_buffer.size() > minimal_size:
                        b_s, b_a, b_r, b_ns, b_d = replay_buffer.sample(batch_size)
                        transition_dict = {
                            'states': b_s,
                            'actions': b_a,
                            'next_states': b_ns,
                            'rewards': b_r,
                            'dones': b_d
                        }
                        agent.update(transition_dict)

                # update interval statistics
                if episode_return > interval_best_return:
                    interval_best_return = episode_return
                if episode_return < interval_worst_return:
                    interval_worst_return = episode_return

                return_list.append(episode_return)
                print(f"Episode {i * int(num_episodes / 125) + i_episode + 1}: Return {episode_return}")

                # plot the learning curve every 40 episodes
                if (i * int(num_episodes / 125) + i_episode + 1) % 40 == 0:
                    pbar.set_postfix({
                        'episode': '%d' % (num_episodes / 125 * i + i_episode + 1),
                        'return': '%.3f' % np.mean(return_list[-40:])
                    })
                    episodes = list(range(1, len(return_list) + 1))
                    plt.figure()
                    plt.plot(episodes, return_list)
                    plt.xlabel('Episodes')
                    plt.ylabel('Return')
                    plt.title('Learning Curve')
                    plt.savefig(f'/media/jerry/System/RL_Result/learning_curve_{i * int(num_episodes / 125) + i_episode + 1}.png')
                    plt.close()

                agent.decay_epsilon()
                pbar.update(1)

                # save models and returns every 250 episodes
                if (i * int(num_episodes / 125) + i_episode + 1) == 1 or \
                   (i * int(num_episodes / 125) + i_episode + 1) % 250 == 0:

                    current_episode = i * int(num_episodes / 125) + i_episode + 1

                    if interval_best_return > highest_return:
                        highest_return = interval_best_return
                        torch.save(agent.q_net.state_dict(),
                                   f'/media/jerry/System/RL_Result/best_model_{current_episode}.pth')
                        print(f"New best model saved with return: {highest_return} at episode {current_episode}")

                    if interval_worst_return < lowest_return:
                        lowest_return = interval_worst_return
                        torch.save(agent.q_net.state_dict(),
                                   f'/media/jerry/System/RL_Result/worst_model_{current_episode}.pth')
                        print(f"New worst model saved with return: {lowest_return} at episode {current_episode}")

                    # save the return history
                    np.save(f'/media/jerry/System/RL_Result/return_list_{current_episode}.npy', return_list)
                    print(f"Return list saved at episode {current_episode}")
