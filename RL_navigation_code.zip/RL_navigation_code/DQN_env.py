import gym
from gym import spaces
import numpy as np
import rospy
import os
from geometry_msgs.msg import Twist
from tf2_msgs.msg import TFMessage
import time
import csv
import math
import subprocess
from common import TransformListener
import threading

class TransformListener:
    def __init__(self):
        if not rospy.core.is_initialized():
            rospy.init_node('transform_listener', anonymous=True)

        self.object_position = np.zeros(3)
        self.xform_position = np.zeros(3)
        self.xform_orientation = np.zeros(4)
        self.contact_force = 0.0
        self.object_lost = False
        self.collision_occurred = False
        self.collision_force = 0.0
        self.object_frame = None
        self.xform_time = None
        self.object_frame_carry = 0
        self.xform_time_carry = 0
        self.reset_signal = 0

        self.robot01_position = np.zeros(3)
        self.robot01_orientation = np.array([0, 0, 0, 1])
        self.robot02_position = np.zeros(3)
        self.robot02_orientation = np.array([0, 0, 0, 1])
        self.dynaOb_positions = [np.zeros(3) for _ in range(4)]
        self.collision01 = [0, 0]  # [whether collision occurred, collision force magnitude]
        self.collision02 = [0, 0]  # [whether collision occurred, collision force magnitude]

        rospy.Subscriber("/object", TFMessage, self.object_callback)
        rospy.Subscriber("/xform", TFMessage, self.xform_callback)
        rospy.Subscriber("/robot01", TFMessage, self.robot01_callback)
        rospy.Subscriber("/robot02", TFMessage, self.robot02_callback)
        rospy.Subscriber("/DynaOb01Collide", TFMessage, self.dynaOb01_collide_callback)
        rospy.Subscriber("/DynaOb02Collide", TFMessage, self.dynaOb02_collide_callback)
        rospy.Subscriber("/DynaOb02", TFMessage, self.dynaOb02_callback)
        rospy.Subscriber("/DynaOb01", TFMessage, self.dynaOb01_callback)
        rospy.Subscriber("/DynaOb03Collide", TFMessage, self.dynaOb03_collide_callback)
        rospy.Subscriber("/DynaOb04Collide", TFMessage, self.dynaOb04_collide_callback)
        rospy.Subscriber("/DynaOb03", TFMessage, self.dynaOb03_callback)
        rospy.Subscriber("/DynaOb04", TFMessage, self.dynaOb04_callback)

        self.velocity_publisher = rospy.Publisher('/rl_vel', Twist, queue_size=10)
        self.reset_publisher = rospy.Publisher('/resetSignal', Twist, queue_size=10)

    def object_callback(self, msg):
        transform = msg.transforms[0]
        translation = transform.transform.translation
        rotation = transform.transform.rotation
        timestamp = transform.header.stamp

        self.object_position = np.array([translation.x, translation.y, translation.z])
        self.contact_force = rotation.x
        self.object_lost = (rotation.y == 0)
        self.collision_occurred = (rotation.z == 1)
        self.collision_force = rotation.w if self.collision_occurred else 0.0

        frame = timestamp.secs % 101
        if frame == 0 and self.object_frame is not None and self.object_frame != 0:
            self.object_frame_carry += 1
        self.object_frame = frame

    def xform_callback(self, msg):
        transform = msg.transforms[0]
        translation = transform.transform.translation
        rotation = transform.transform.rotation
        timestamp = transform.header.stamp

        self.xform_position = np.array([translation.x, translation.y, translation.z])
        self.xform_orientation = np.array([rotation.x, rotation.y, rotation.z, rotation.w])

        # rospy.loginfo(f"Updated xform_position: {self.xform_position}")

        time = timestamp.secs + timestamp.nsecs / 1e9
        time = (time * 60) % 100
        if time == 0 and self.xform_time is not None and self.xform_time != 0:
            self.xform_time_carry += 1
        self.xform_time = time

    def robot01_callback(self, msg):
        transform = msg.transforms[0]
        translation = transform.transform.translation
        rotation = transform.transform.rotation

        self.robot01_position = np.array([translation.x, translation.y, translation.z])
        self.robot01_orientation = np.array([rotation.x, rotation.y, rotation.z, rotation.w])

    def robot02_callback(self, msg):
        transform = msg.transforms[0]
        translation = transform.transform.translation
        rotation = transform.transform.rotation

        self.robot02_position = np.array([translation.x, translation.y, translation.z])
        self.robot02_orientation = np.array([rotation.x, rotation.y, rotation.z, rotation.w])

    def dynaOb01_collide_callback(self, msg):
        transform = msg.transforms[0]
        translation = transform.transform.translation

        self.collision01 = [translation.x, translation.y]  # translation.x indicates collision occurrence, translation.y indicates collision force magnitude

    def dynaOb02_collide_callback(self, msg):
        transform = msg.transforms[0]
        translation = transform.transform.translation

        self.collision02 = [translation.x, translation.y]  # translation.x indicates collision occurrence, translation.y indicates collision force magnitude
        
    def dynaOb03_collide_callback(self, msg):
        transform = msg.transforms[0]
        translation = transform.transform.translation

        self.collision03 = [translation.x, translation.y]  # translation.x indicates collision occurrence, translation.y indicates collision force magnitude

    def dynaOb04_collide_callback(self, msg):
        transform = msg.transforms[0]
        translation = transform.transform.translation

        self.collision04 = [translation.x, translation.y]  # translation.x indicates collision occurrence, translation.y indicates collision force magnitude

    def dynaOb03_callback(self, msg):
        transform = msg.transforms[0]
        translation = transform.transform.translation

        self.dynaOb_positions[2] = np.array([translation.x, translation.y, 0.0])  # Only need xy coordinates

    def dynaOb04_callback(self, msg):
        transform = msg.transforms[0]
        translation = transform.transform.translation

        self.dynaOb_positions[3] = np.array([translation.x, translation.y, 0.0])  # Only need xy coordinates

    def dynaOb02_callback(self, msg):
        transform = msg.transforms[0]
        translation = transform.transform.translation

        self.dynaOb_positions[1] = np.array([translation.x, translation.y, 0.0])  # Only need xy coordinates
        
    def dynaOb01_callback(self, msg):
        transform = msg.transforms[0]
        translation = transform.transform.translation

        self.dynaOb_positions[0] = np.array([translation.x, translation.y, 0.0])  # Only need xy coordinates
        
    def dynaOb03_callback(self, msg):
        transform = msg.transforms[0]
        translation = transform.transform.translation
        self.dynaOb_positions[2] = np.array([translation.x, translation.y, 0.0])  # Store the position of the third dynamic obstacle

    def dynaOb04_callback(self, msg):
        transform = msg.transforms[0]
        translation = transform.transform.translation
        self.dynaOb_positions[3] = np.array([translation.x, translation.y, 0.0])  # Store the position of the fourth dynamic obstacle

    def publish_velocity(self, linear_velocity_x, linear_velocity_y, angular_velocity_z):
        twist_msg = Twist()
        twist_msg.linear.x = linear_velocity_x
        twist_msg.linear.y = linear_velocity_y
        twist_msg.angular.z = angular_velocity_z
        self.velocity_publisher.publish(twist_msg)

    def publish_reset_signal(self, reset_needed):
        twist_msg = Twist()
        twist_msg.angular.x = float(reset_needed)
        self.reset_publisher.publish(twist_msg)

    def get_state(self, step_index, csv_length, step_size, yaw_error):
        progress = step_index / csv_length

        distance_to_object = np.linalg.norm(self.xform_position[:2] - self.object_position[:2])
        # Added calculation of distance between xform and the second robot
        
        # Calculate the initial distance between xform and the second robot (based on the provided initial positions)
        distance_to_robot02 = np.linalg.norm(self.xform_position[:2] - self.robot02_position[:2]) - np.linalg.norm(np.array([2, -15]) - np.array([1.898, -15]))
        # Print distance to object

        # rospy.loginfo(f"Distance to Object: {distance_to_object}")

        state = np.array([
            progress,
            step_size,    # step_size at the current timestep
            distance_to_object,
            yaw_error,    # yaw_error at the current timestep
            distance_to_robot02  # added this new state dimension
        ])
        return state

    def spin(self):
        rospy.spin()


class NewDDPGEnv(gym.Env):
    def __init__(self, listener, csv_path):
        super(NewDDPGEnv, self).__init__()
        ######
        ######
        self.cumulative_reward = 0  # Initialize cumulative reward to 0
        
        self.action_space = spaces.Discrete(10)  # 10 stride levels
        
        self.last_time = rospy.Time.now()  # Initialize time tracking variable

        self.csv_path = csv_path
        self.load_path(csv_path)
        self.listener = listener
        self.velocity_publisher = rospy.Publisher('/rl_vel', Twist, queue_size=10)
        self.reset_publisher = rospy.Publisher('/resetSignal', Twist, queue_size=10)

        self.control_rate = rospy.Rate(5)  # Control signal publish rate at 5Hz
        self.comm_rate = rospy.Rate(60)  # ROS communication rate at 60Hz

        self.current_index = 0
        self.object_lost_counter = 0  # Counter for object lost status
        self.ignore_rotation = False  # Flag to ignore rotation
        self.ignore_rotation_end_index = -1  # Index to end ignoring rotation

        self.move_duration = 1 / 5  # Each timestep is 1/5 second
        self.last_time = rospy.Time.now()

        state_dim = 5  # Five-dimensional state space
        self.observation_space = spaces.Box(
            low=-np.inf,
            high=np.inf,
            shape=(state_dim,),
            dtype=np.float64
        )

    def load_path(self, csv_path):
        self.path = []
        try:
            with open(csv_path, 'r') as file:
                reader = csv.reader(file)
                next(reader)  # Skip header
                self.path = [(float(row[0]), float(row[1])) for row in reader]
            rospy.loginfo("Path loaded from CSV file.")
        except Exception as e:
            rospy.logerr(f"Failed to load path from CSV file: {e}")

    def step(self, action):
        step_size = 10.344 + (action + 1) * 0.156  # Convert action index to step size

        next_index = min(int(self.current_index + step_size), len(self.path) - 1)
        
        current_time = rospy.Time.now()  # Get current time
        dt = (current_time - self.last_time).to_sec()  # Calculate time difference
        self.last_time = current_time  # Update last_time to current time

        current_x, current_y = self.listener.xform_position[:2]
        target_x, target_y = self.path[next_index]

        dx = target_x - current_x
        dy = target_y - current_y
        distance = np.linalg.norm([dx, dy])
        
        # linear velocity scaling factor and angular velocity scaling factor
        v_factor = 0.28   
        w_factor = 1
        
        vx = v_factor * dx / self.move_duration
        #vx = dx / dt
        vy = v_factor * dy / self.move_duration
        #vy = dy / dt

        yaw = self.get_current_yaw()
        target_yaw = math.atan2(dy, dx)
        yaw_error = self.compute_yaw_error(target_yaw, yaw)

        if not self.ignore_rotation:
            self.check_future_yaw_difference(next_index)

        if abs(yaw_error) > math.pi / 10:
            yaw_error = 0

        if self.ignore_rotation and self.current_index < self.ignore_rotation_end_index:
            yaw_error = 0
        else:
            self.ignore_rotation = False

        angular_velocity_z = w_factor * math.degrees(yaw_error) / self.move_duration
        #angular_velocity_z = math.degrees(yaw_error) / dt

        reward, done = self.calculate_reward(next_index, action)

        self.cumulative_reward += reward  # Update cumulative reward
            
        if done:
            self.publish_velocity(0.0, 0.0, 0.0)
            self.publish_reset_signal(1.0)
            time.sleep(2)  # Wait for reset signal to take effect
            self.publish_reset_signal(0.0)
        else:
            self.publish_velocity(vx, vy, angular_velocity_z)
            self.publish_reset_signal(0.0)

        time.sleep(self.move_duration)

        observation = self.get_observation(next_index, len(self.path), step_size, yaw_error)  # Pass step_size and yaw_error
        # Print state information here for debugging

        self.current_index = next_index

        return observation, reward, done, {}

    def publish_velocity(self, linear_velocity_x, linear_velocity_y, angular_velocity_z):
        twist_msg = Twist()
        twist_msg.linear.x = linear_velocity_x
        twist_msg.linear.y = linear_velocity_y
        twist_msg.angular.z = angular_velocity_z
        self.velocity_publisher.publish(twist_msg)

    def publish_reset_signal(self, signal):
        twist_msg = Twist()
        twist_msg.angular.x = signal
        self.reset_publisher.publish(twist_msg)

    def get_current_yaw(self):
        if self.listener.xform_orientation is None:
            return 0.0
        x, y, z, w = self.listener.xform_orientation
        yaw = np.arctan2(2.0 * (w * z + x * y), 1.0 - 2.0 * (y * y + z * z))
        return yaw

    def compute_yaw_error(self, target_yaw, current_yaw):
        yaw_error_1 = target_yaw - current_yaw
        yaw_error_2 = target_yaw - (current_yaw + math.pi)
        
        if yaw_error_1 > math.pi:
            yaw_error_1 -= 2 * math.pi
        elif yaw_error_1 < -math.pi:
            yaw_error_1 += 2 * math.pi
        
        if yaw_error_2 > math.pi:
            yaw_error_2 -= 2 * math.pi
        elif yaw_error_2 < -math.pi:
            yaw_error_2 += 2 * math.pi
        
        if abs(yaw_error_1) < abs(yaw_error_2):
            if abs(yaw_error_1) > math.pi / 10:
                yaw_error_1 = 0    
            return yaw_error_1
        else:
            if abs(yaw_error_2) > math.pi / 10:
                yaw_error_2 = 0   
            return yaw_error_2

    def check_future_yaw_difference(self, next_index):
        future_steps = 100
        if next_index + future_steps + 1 < len(self.path):
            current_target_yaw = math.atan2(
                self.path[next_index + 1][1] - self.path[next_index][1],
                self.path[next_index + 1][0] - self.path[next_index][0]
            )
            future_target_yaw = math.atan2(
                self.path[next_index + future_steps + 1][1] - self.path[next_index + future_steps][1],
                self.path[next_index + future_steps + 1][0] - self.path[next_index + future_steps][0]
            )
            yaw_diff = future_target_yaw - current_target_yaw
            if yaw_diff > math.pi:
                yaw_diff -= 2 * math.pi
            elif yaw_diff < -math.pi:
                yaw_diff += 2 * math.pi

            if abs(yaw_diff) > math.pi / 2:
                self.ignore_rotation = True
                self.ignore_rotation_end_index = next_index + future_steps

    def calculate_reward(self, step_index, action):
        reward = -1
        done = False
        reset_reason = ""

        distance_to_object = np.linalg.norm(self.listener.xform_position[:2] - self.listener.object_position[:2])
        distance_to_goal = np.linalg.norm(self.listener.object_position[:2] - np.array([10, -11.2]))

        if distance_to_object < 0.05:
            reward += 3    
        elif 0.05 <= distance_to_object <= 0.1:
            reward -=  0
        elif distance_to_object > 0.1:
            reward -=  (distance_to_object - 0.1) * 150
            if distance_to_object > 0.20:  
                reward -= 15    
                # done = True
                reset_reason = "Distance to object too large"

        # Logic for handling object loss
        if self.listener.object_lost:
            self.object_lost_counter += 1
            reward -= 15   # Penalize -15 for each loss
            if self.object_lost_counter >= 10:  # If consecutive loss count reaches 10
                reward -= 17
                reset_reason = "Object lost for too long"
        else:
            self.object_lost_counter = 0  # Reset counter if object is not lost

        if 0.05 < self.listener.contact_force < 10:
            reward += 5 
        elif self.listener.contact_force <= 0.05:
            reward -= -5 + (0.05 - self.listener.contact_force) * 350 
        elif 10 <= self.listener.contact_force < 20:
            reward -= -5 + (self.listener.contact_force - 10) * 2.5 
        elif self.listener.contact_force >= 20:
            reward -= 20 

        if action > 5:
            reward += 0.85 * (30 + (action - 5) * (40 - 8) / 4)  # Linear interpolation, from 30 to 50 and from 8 to 12 
        elif action < 2:
            reward += 0.85 * (-10 + (action - 2) * (50 - 40) / 2)  # Linear interpolation, from -20 to -100
        else:
            # reward += 0.85 * (-2 + (action - 2) * (44 - 8) / 4)   # Reward when action == 5
            reward += 17 + (action - 2) * (23 - 8) / 4   # Reward when action == 5

        progress = step_index / len(self.path)
        if progress >= 0.999:
             reward += 300
             done = True
             reset_reason = "Progress exceeded 99.9%"
        
        if done:
            rospy.loginfo(f"Episode reset due to: {reset_reason}")

        return reward, done

    def get_observation(self, step_index, csv_length, step_size, yaw_error):
        return self.listener.get_state(step_index, csv_length, step_size, yaw_error)

    def reset(self):
        # Stop all motion
        self.publish_velocity(0.0, 0.0, 0.0)  # Ensure object is fully stopped
        time.sleep(0.1)  # Wait for stop command to take effect

        # Reset environment state
        self.current_index = 0
        self.object_lost_counter = 0
        self.cumulative_reward = 0  # Reset cumulative reward

        # Reset position and other state information
        self.listener.object_position = np.zeros(3)
        self.listener.xform_position = np.zeros(3)
        self.listener.robot01_position = np.zeros(3)
        self.listener.robot02_position = np.zeros(3)

        # Send reset signal
        self.publish_reset_signal(1.0)
        time.sleep(1.0)
        
        # Initialize step_size and yaw_error
        initial_step_size = 0
        initial_yaw_error = 0
        observation = self.get_observation(self.current_index, len(self.path), initial_step_size, initial_yaw_error)

        # Cancel reset signal
        self.publish_reset_signal(0.0)
        return observation

    def render(self, mode='human'):
        pass

    def close(self):
        rospy.signal_shutdown("Environment closed.")

if __name__ == "__main__":
    csv_path = "/media/jerry/System/PythonImage/generate/smooth/smoothed_path.csv"
    listener = TransformListener()
    env = NewDDPGEnv(listener, csv_path)

    # Call reset and hold for 1 second
    env.publish_reset_signal(1.0)
    time.sleep(1.0)
    env.publish_reset_signal(0.0)

    env.reset()

    rospy.loginfo("Waiting 2 seconds before running...")
    time.sleep(2)

    try:
        for _ in range(10000):
            action = 0  
            state, reward, done, _ = env.step(action)
            print(f"State: {state}, Reward: {reward}, Cumulative Reward: {env.cumulative_reward}, Done: {done}")
            
            if done:
                rospy.loginfo("Episode ended. Resetting environment.")
                env.reset()  # Immediately reset environment when done
                break
    finally:
        env.close()
