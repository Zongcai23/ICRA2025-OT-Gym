import gym
from gym import spaces
import numpy as np
import rospy
import os
from geometry_msgs.msg import Twist
from tf2_msgs.msg import TFMessage
import time
import csv
import math
import subprocess
from common import TransformListener
import threading
#from DQN_env import TransformListener, NewDDPGEnv
#from data_logger import start_data_logging  # 导入数据记录函数






class TransformListener:
    def __init__(self):
        if not rospy.core.is_initialized():
            rospy.init_node('transform_listener', anonymous=True)

        self.object_position = np.zeros(3)
        self.xform_position = np.zeros(3)
        self.xform_orientation = np.zeros(4)
        self.contact_force = 0.0
        self.object_lost = False
        self.collision_occurred = False
        self.collision_force = 0.0
        self.object_frame = None
        self.xform_time = None
        self.object_frame_carry = 0
        self.xform_time_carry = 0
        self.reset_signal = 0

        self.robot01_position = np.zeros(3)
        self.robot01_orientation = np.array([0, 0, 0, 1])
        self.robot02_position = np.zeros(3)
        self.robot02_orientation = np.array([0, 0, 0, 1])
        self.dynaOb_positions = [np.zeros(3) for _ in range(4)]
        self.collision01 = [0, 0]  # [是否发生碰撞, 碰撞力大小]
        self.collision02 = [0, 0]  # [是否发生碰撞, 碰撞力大小]

        rospy.Subscriber("/object", TFMessage, self.object_callback)
        rospy.Subscriber("/xform", TFMessage, self.xform_callback)
        rospy.Subscriber("/robot01", TFMessage, self.robot01_callback)
        rospy.Subscriber("/robot02", TFMessage, self.robot02_callback)
        rospy.Subscriber("/DynaOb01Collide", TFMessage, self.dynaOb01_collide_callback)
        rospy.Subscriber("/DynaOb02Collide", TFMessage, self.dynaOb02_collide_callback)
        rospy.Subscriber("/DynaOb02", TFMessage, self.dynaOb02_callback)
        rospy.Subscriber("/DynaOb01", TFMessage, self.dynaOb01_callback)
        rospy.Subscriber("/DynaOb03Collide", TFMessage, self.dynaOb03_collide_callback)
        rospy.Subscriber("/DynaOb04Collide", TFMessage, self.dynaOb04_collide_callback)
        rospy.Subscriber("/DynaOb03", TFMessage, self.dynaOb03_callback)
        rospy.Subscriber("/DynaOb04", TFMessage, self.dynaOb04_callback)


        

        self.velocity_publisher = rospy.Publisher('/rl_vel', Twist, queue_size=10)
        self.reset_publisher = rospy.Publisher('/resetSignal', Twist, queue_size=10)

    def object_callback(self, msg):
        transform = msg.transforms[0]
        translation = transform.transform.translation
        rotation = transform.transform.rotation
        timestamp = transform.header.stamp

        self.object_position = np.array([translation.x, translation.y, translation.z])
        self.contact_force = rotation.x
        self.object_lost = (rotation.y == 0)
        self.collision_occurred = (rotation.z == 1)
        self.collision_force = rotation.w if self.collision_occurred else 0.0




        frame = timestamp.secs % 101
        if frame == 0 and self.object_frame is not None and self.object_frame != 0:
            self.object_frame_carry += 1
        self.object_frame = frame

    def xform_callback(self, msg):
        transform = msg.transforms[0]
        translation = transform.transform.translation
        rotation = transform.transform.rotation
        timestamp = transform.header.stamp

        self.xform_position = np.array([translation.x, translation.y, translation.z])
        self.xform_orientation = np.array([rotation.x, rotation.y, rotation.z, rotation.w])

        #rospy.loginfo(f"Updated xform_position: {self.xform_position}")

        time = timestamp.secs + timestamp.nsecs / 1e9
        time = (time * 60) % 100
        if time == 0 and self.xform_time is not None and self.xform_time != 0:
            self.xform_time_carry += 1
        self.xform_time = time

    def robot01_callback(self, msg):
        transform = msg.transforms[0]
        translation = transform.transform.translation
        rotation = transform.transform.rotation

        self.robot01_position = np.array([translation.x, translation.y, translation.z])
        self.robot01_orientation = np.array([rotation.x, rotation.y, rotation.z, rotation.w])

    def robot02_callback(self, msg):
        transform = msg.transforms[0]
        translation = transform.transform.translation
        rotation = transform.transform.rotation

        self.robot02_position = np.array([translation.x, translation.y, translation.z])
        self.robot02_orientation = np.array([rotation.x, rotation.y, rotation.z, rotation.w])

    def dynaOb01_collide_callback(self, msg):
        transform = msg.transforms[0]
        translation = transform.transform.translation

        self.collision01 = [translation.x, translation.y]  # translation.x 表示碰撞发生与否，translation.y 表示碰撞力大小

    def dynaOb02_collide_callback(self, msg):
        transform = msg.transforms[0]
        translation = transform.transform.translation

        self.collision02 = [translation.x, translation.y]  # translation.x 表示碰撞发生与否，translation.y 表示碰撞力大小
        
    def dynaOb03_collide_callback(self, msg):
        transform = msg.transforms[0]
        translation = transform.transform.translation

        self.collision03 = [translation.x, translation.y]  # translation.x 表示碰撞发生与否，translation.y 表示碰撞力大小

    def dynaOb04_collide_callback(self, msg):
        transform = msg.transforms[0]
        translation = transform.transform.translation

        self.collision04 = [translation.x, translation.y]  # translation.x 表示碰撞发生与否，translation.y 表示碰撞力大小

    def dynaOb03_callback(self, msg):
        transform = msg.transforms[0]
        translation = transform.transform.translation

        self.dynaOb_positions[2] = np.array([translation.x, translation.y, 0.0])  # 只需要xy坐标

    def dynaOb04_callback(self, msg):
        transform = msg.transforms[0]
        translation = transform.transform.translation

        self.dynaOb_positions[3] = np.array([translation.x, translation.y, 0.0])  # 只需要xy坐标


    def dynaOb02_callback(self, msg):
        transform = msg.transforms[0]
        translation = transform.transform.translation

        self.dynaOb_positions[1] = np.array([translation.x, translation.y, 0.0])  # 只需要xy坐标
        
    def dynaOb01_callback(self, msg):
        transform = msg.transforms[0]
        translation = transform.transform.translation

        self.dynaOb_positions[0] = np.array([translation.x, translation.y, 0.0])  # 只需要xy坐标
        
    def dynaOb03_callback(self, msg):
        transform = msg.transforms[0]
        translation = transform.transform.translation
        self.dynaOb_positions[2] = np.array([translation.x, translation.y, 0.0])  # 存储第三个动态障碍物的位置

    def dynaOb04_callback(self, msg):
        transform = msg.transforms[0]
        translation = transform.transform.translation
        self.dynaOb_positions[3] = np.array([translation.x, translation.y, 0.0])  # 存储第四个动态障碍物的位置


    def publish_velocity(self, linear_velocity_x, linear_velocity_y, angular_velocity_z):
        twist_msg = Twist()
        twist_msg.linear.x = linear_velocity_x
        twist_msg.linear.y = linear_velocity_y
        twist_msg.angular.z = angular_velocity_z
        self.velocity_publisher.publish(twist_msg)

    def publish_reset_signal(self, reset_needed):
        twist_msg = Twist()
        twist_msg.angular.x = float(reset_needed)
        self.reset_publisher.publish(twist_msg)

    def get_state(self, step_index, csv_length, step_size, yaw_error):
        progress = step_index / csv_length

        distance_to_object = np.linalg.norm(self.xform_position[:2] - self.object_position[:2])
        # 新增计算 xform 与 第二个机器人之间的距离
        
        # 计算初始的xform与第二个机器人之间的距离（根据你提供的初始位置）
        distance_to_robot02 = np.linalg.norm(self.xform_position[:2] - self.robot02_position[:2]) - np.linalg.norm(np.array([2, -15]) - np.array([1.898, -15]))
        # 打印 distance to object


        #rospy.loginfo(f"Distance to Object: {distance_to_object}")

        state = np.array([
            progress,
            step_size,    # 当前时间步的step_size
            distance_to_object,
            yaw_error,    # 当前时间步的yaw_error
            distance_to_robot02  # 添加这个新的状态维度
            
        ])
        return state

    def spin(self):
        rospy.spin()


class NewDDPGEnv(gym.Env):
    def __init__(self, listener, csv_path):
        super(NewDDPGEnv, self).__init__()
        ######
        ######
        self.cumulative_reward = 0  # 累积reward初始化为0
        
        self.action_space = spaces.Discrete(10)  # 10 个步幅档位
        
        self.last_time = rospy.Time.now()  # 添加这一行来初始化时间跟踪变量

        self.csv_path = csv_path
        self.load_path(csv_path)
        self.listener = listener
        self.velocity_publisher = rospy.Publisher('/rl_vel', Twist, queue_size=10)
        self.reset_publisher = rospy.Publisher('/resetSignal', Twist, queue_size=10)

        self.control_rate = rospy.Rate(5)  # 控制信号发布频率为5Hz
        self.comm_rate = rospy.Rate(60)  # ROS通信频率为60Hz

        self.current_index = 0
        self.object_lost_counter = 0  # 用于计算object丢失状态的计数器
        self.ignore_rotation = False  # 忽略旋转标志
        self.ignore_rotation_end_index = -1  # 忽略旋转的终点索引

        self.move_duration = 1 / 5  # 每个时间步长为1/30秒
        self.last_time = rospy.Time.now()

        #state_dim = 8  # 五维状态空间
        #state_dim = 4  # 修改后的4维状态空间
        state_dim = 5  # 现在是五维状态空间
        self.observation_space = spaces.Box(
            low=-np.inf,
            high=np.inf,
            shape=(state_dim,),
            dtype=np.float64
        )

    def load_path(self, csv_path):
        self.path = []
        try:
            with open(csv_path, 'r') as file:
                reader = csv.reader(file)
                next(reader)  # Skip header
                self.path = [(float(row[0]), float(row[1])) for row in reader]
            rospy.loginfo("Path loaded from CSV file.")
        except Exception as e:
            rospy.logerr(f"Failed to load path from CSV file: {e}")

    def step(self, action):
        step_size = 10.344 + (action + 1) * 0.156  # 动作索引转换为步幅 原来的参数是9.92 0.583

        next_index = min(int(self.current_index + step_size), len(self.path) - 1)
        
        current_time = rospy.Time.now()  # 获取当前时间
        dt = (current_time - self.last_time).to_sec()  # 计算时间差
        self.last_time = current_time  # 更新 last_time 为当前时间


        current_x, current_y = self.listener.xform_position[:2]
        target_x, target_y = self.path[next_index]

        dx = target_x - current_x
        dy = target_y - current_y
        distance = np.linalg.norm([dx, dy])
        
        #线速度缩放因子和角速度缩放因子
        v_factor = 0.28   #原来是0.222
        w_factor = 1
        
        
        vx = v_factor * dx / self.move_duration
        #vx = dx / dt
        vy = v_factor * dy / self.move_duration
        #vy = dy / dt

        yaw = self.get_current_yaw()
        target_yaw = math.atan2(dy, dx)
        yaw_error = self.compute_yaw_error(target_yaw, yaw)

        if not self.ignore_rotation:
            self.check_future_yaw_difference(next_index)

        if abs(yaw_error) > math.pi / 10:
            yaw_error = 0

        if self.ignore_rotation and self.current_index < self.ignore_rotation_end_index:
            yaw_error = 0
        else:
            self.ignore_rotation = False

        angular_velocity_z = w_factor * math.degrees(yaw_error) / self.move_duration
        #angular_velocity_z = math.degrees(yaw_error) / dt

        reward, done = self.calculate_reward(next_index, action)
        #####
        #####
        self.cumulative_reward += reward  # 更新累积reward

            
            
        if done:
            self.publish_velocity(0.0, 0.0, 0.0)
            self.publish_reset_signal(1.0)
            time.sleep(2)  # 等待重置信号生效
            self.publish_reset_signal(0.0)
        else:
            self.publish_velocity(vx, vy, angular_velocity_z)
            self.publish_reset_signal(0.0)

        time.sleep(self.move_duration)




        #observation = self.get_observation(next_index, len(self.path))
        observation = self.get_observation(next_index, len(self.path), step_size, yaw_error)  # 传递step_size和yaw_error
        # 在这里打印state信息，用于调试

        
        self.current_index = next_index

        return observation, reward, done, {}

    def publish_velocity(self, linear_velocity_x, linear_velocity_y, angular_velocity_z):
        twist_msg = Twist()
        twist_msg.linear.x = linear_velocity_x
        twist_msg.linear.y = linear_velocity_y
        twist_msg.angular.z = angular_velocity_z
        self.velocity_publisher.publish(twist_msg)

    def publish_reset_signal(self, signal):
        twist_msg = Twist()
        twist_msg.angular.x = signal
        self.reset_publisher.publish(twist_msg)

    def get_current_yaw(self):
        if self.listener.xform_orientation is None:
            return 0.0
        x, y, z, w = self.listener.xform_orientation
        yaw = np.arctan2(2.0 * (w * z + x * y), 1.0 - 2.0 * (y * y + z * z))
        return yaw

    def compute_yaw_error(self, target_yaw, current_yaw):
        yaw_error_1 = target_yaw - current_yaw
        yaw_error_2 = target_yaw - (current_yaw + math.pi)
        
        if yaw_error_1 > math.pi:
            yaw_error_1 -= 2 * math.pi
        elif yaw_error_1 < -math.pi:
            yaw_error_1 += 2 * math.pi
        
        if yaw_error_2 > math.pi:
            yaw_error_2 -= 2 * math.pi
        elif yaw_error_2 < -math.pi:
            yaw_error_2 += 2 * math.pi
        
        if abs(yaw_error_1) < abs(yaw_error_2):
            if abs(yaw_error_1) > math.pi / 10:
                yaw_error_1 = 0    
            return yaw_error_1
        else:
            if abs(yaw_error_2) > math.pi / 10:
                yaw_error_2 = 0   
            return yaw_error_2


    def check_future_yaw_difference(self, next_index):
        future_steps = 100
        if next_index + future_steps + 1 < len(self.path):
            current_target_yaw = math.atan2(
                self.path[next_index + 1][1] - self.path[next_index][1],
                self.path[next_index + 1][0] - self.path[next_index][0]
            )
            future_target_yaw = math.atan2(
                self.path[next_index + future_steps + 1][1] - self.path[next_index + future_steps][1],
                self.path[next_index + future_steps + 1][0] - self.path[next_index + future_steps][0]
            )
            yaw_diff = future_target_yaw - current_target_yaw
            if yaw_diff > math.pi:
                yaw_diff -= 2 * math.pi
            elif yaw_diff < -math.pi:
                yaw_diff += 2 * math.pi

            if abs(yaw_diff) > math.pi / 2:
                self.ignore_rotation = True
                self.ignore_rotation_end_index = next_index + future_steps

    def calculate_reward(self, step_index, action):
        reward = -1
        done = False
        reset_reason = ""

        distance_to_object = np.linalg.norm(self.listener.xform_position[:2] - self.listener.object_position[:2])
        distance_to_goal = np.linalg.norm(self.listener.object_position[:2] - np.array([10, -11.2]))


            
        if distance_to_object < 0.05:
            reward += 3    #原来是6
        elif 0.05 <= distance_to_object <= 0.1:
            reward -=  0
        elif distance_to_object > 0.1:
            reward -=  (distance_to_object - 0.1) * 150#原来前面的数字是20
            if distance_to_object > 0.20:  #原来是0.3 0.2
                reward -= 15    #原来是-2000
                #done = True
                reset_reason = "Distance to object too large"


        
            # 物体丢失处理逻辑
        if self.listener.object_lost:
            self.object_lost_counter += 1
            reward -= 15   # 每次丢失都给予-100的惩罚
            if self.object_lost_counter >= 10:  # 如果连续丢失次数达到20次 30
                reward -= 17  # 给予-4000的惩罚 1000 原来是17
                #done = True  # 结束当前episode
                reset_reason = "Object lost for too long"
        else:
            self.object_lost_counter = 0  # 如果物体未丢失，重置计数器


            
        if 0.05 < self.listener.contact_force < 10:
            reward += 5 #原先是20 从+5改成+2是为了不会让agent沉迷于慢速获得奖励 原来是5
        elif self.listener.contact_force <= 0.05:
            reward -= -5 + (0.05 - self.listener.contact_force) * 350 #原来是200 原来前面的数字都是10 #原来是35 40
        elif 10 <= self.listener.contact_force < 20:
            reward -= -5 + (self.listener.contact_force - 10) * 2.5 #原来是83 原来前面的数字都是10 #原来是35，2.1
        elif self.listener.contact_force >= 20:
            reward -= 20 #原来是83 原来前面的数字都是10 #原来是35，2.1

        #reward += 20 * (action / 9) #原先是2
        
        if action > 5:
            reward += 0.85 * (30 + (action - 5) * (40 - 8) / 4)  # 线性插值，从 30 增加到 50  从8到 12 
        elif action < 2:
            reward += 0.85 * (-10 + (action - 2) * (50 - 40) / 2)  # 线性插值，从 -20 减少到 -100
        else:
            #reward += 0.85 * (-2 + (action - 2) * (44 - 8) / 4)   # action == 5 时的奖励
            reward += 17 + (action - 2) * (23 - 8) / 4   # action == 5 时的奖励

        progress = step_index / len(self.path)
        if progress >= 0.999:
             reward += 300
             done = True
             reset_reason = "Progress exceeded 99.9%"
        
        if done:
            rospy.loginfo(f"Episode reset due to: {reset_reason}")

        return reward, done

    #def get_observation(self, step_index, csv_length):
        #return self.listener.get_state(step_index, csv_length)
    def get_observation(self, step_index, csv_length, step_size, yaw_error):
        return self.listener.get_state(step_index, csv_length, step_size, yaw_error)
    def reset(self):
        # 停止所有运动
        self.publish_velocity(0.0, 0.0, 0.0)  # 确保物体完全停止
        time.sleep(0.1)  # 等待停止命令生效

        # 重置环境状态
        self.current_index = 0
        self.object_lost_counter = 0
        self.cumulative_reward = 0  # 重置累积reward

        # 重置位置等状态信息
        self.listener.object_position = np.zeros(3)
        self.listener.xform_position = np.zeros(3)
        self.listener.robot01_position = np.zeros(3)
        self.listener.robot02_position = np.zeros(3)

        # 发送 reset 信号
        self.publish_reset_signal(1.0)
        time.sleep(1.0)
        
        # 初始化 step_size 和 yaw_error
        initial_step_size = 0
        initial_yaw_error = 0
        observation = self.get_observation(self.current_index, len(self.path), initial_step_size, initial_yaw_error)

        # 取消 reset 信号
        self.publish_reset_signal(0.0)
        return observation



############
    def render(self, mode='human'):
        pass

    def close(self):
        rospy.signal_shutdown("Environment closed.")

if __name__ == "__main__":
    csv_path = "/media/jerry/System/PythonImage/generate/smooth/smoothed_path.csv"
    listener = TransformListener()
    env = NewDDPGEnv(listener, csv_path)

    # 调用 reset 并保持 1 秒
    env.publish_reset_signal(1.0)
    time.sleep(1.0)
    env.publish_reset_signal(0.0)

    env.reset()

    rospy.loginfo("等待 2 秒后开始运行...")
    time.sleep(2)

    # 启动数据记录功能，并将其放在一个独立线程中运行
#    data_logger_thread = threading.Thread(target=start_data_logging)
#    data_logger_thread.start()

    try:
        for _ in range(10000):
            action = 0  
            state, reward, done, _ = env.step(action)
            print(f"State: {state}, Reward: {reward}, Cumulative Reward: {env.cumulative_reward}, Done: {done}")
            
            if done:
                rospy.loginfo("Episode ended. Resetting environment.")
                env.reset()  # 在done条件下立即重置环境
                break
    finally:
        env.close()
        # 等待数据记录线程结束
#        data_logger_thread.join()


