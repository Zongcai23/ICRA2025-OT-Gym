




#!/usr/bin/env python
import rospy
import numpy as np
import time
from geometry_msgs.msg import Twist
from tf2_msgs.msg import TFMessage
from geomagic_control.msg import DeviceFeedback

class ForceFeedbackPublisher:
    def __init__(self):
        rospy.init_node('force_feedback_publisher')
        
        # 设定阈值和参数
        self.threshold_1 = 0.08
        self.threshold_2 = 0.1
        self.angular_x = -12000
        self.angular_y = -16.18 #原来是-25
        self.linear_z = -1568 #原来是-2450

        # 虚拟阻尼和滤波参数
        self.damping_coefficient = 0  # 阻尼系数
        self.alpha = 0.05  # 低通滤波系数，0 < alpha < 1 原来是0.2

        # 存储距离和时间，用于计算距离变化速度
        self.previous_distance = None
        self.previous_time = None

        # 初始化低通滤波后的力
        self.filtered_force = np.array([0.0, 0.0, 0.0])

        # 订阅所需的主题
        self.ot_subscriber = rospy.Subscriber('/secondOTposition', TFMessage, self.ot_centre1_callback)
        self.cube1_subscriber = rospy.Subscriber('/robot02', TFMessage, self.cube1_callback)
        self.dynaob_subscribers = [
            rospy.Subscriber('/DynaOb01', TFMessage, self.dynaob_callback, callback_args=0),
            rospy.Subscriber('/DynaOb02', TFMessage, self.dynaob_callback, callback_args=1),
            rospy.Subscriber('/DynaOb03', TFMessage, self.dynaob_callback, callback_args=2),
            rospy.Subscriber('/DynaOb04', TFMessage, self.dynaob_callback, callback_args=3)
        ]
        self.xform_subscriber = rospy.Subscriber('/xform', TFMessage, self.xform_callback)
        
        # 发布力反馈的主题
        self.force_feedback_publisher = rospy.Publisher('force_feedback', DeviceFeedback, queue_size=1)
        
        # 初始化变量
        self.ot_centre1_pos = None
        self.cube1_pos = None
        self.dynaob_positions = [None] * 4
        self.xform_pos = None
#
#
#
#
#
#

        # 设定阈值和参数
        self.twist_alpha = 0.05  # 为 Twist 过滤设置的滤波系数 原来是0.2
        self.filtered_linear = np.array([0.0, 0.0, 0.0])
        self.filtered_angular = np.array([0.0, 0.0, 0.0])

        # 订阅 /Geomagic2/twist 主题
        self.twist_subscriber = rospy.Subscriber('/Geomagic2/twist', Twist, self.twist_callback)
        self.smoothed_twist_publisher = rospy.Publisher('/Geomagic2/smoothedTwist', Twist, queue_size=1)

    def ot_centre1_callback(self, msg):
        for transform in msg.transforms:
            self.ot_centre1_pos = np.array([transform.transform.translation.x,
                                            transform.transform.translation.y,
                                            transform.transform.translation.z])
        rospy.loginfo("Received otCentre1 position: {}".format(self.ot_centre1_pos))
        self.calculate_and_publish_force()

    def cube1_callback(self, msg):
        for transform in msg.transforms:
            self.cube1_pos = np.array([transform.transform.translation.x,
                                       transform.transform.translation.y,
                                       transform.transform.translation.z])
        rospy.loginfo("Received Cube1 position: {}".format(self.cube1_pos))
        self.calculate_and_publish_force()

    def dynaob_callback(self, msg, index):
        for transform in msg.transforms:
            self.dynaob_positions[index] = np.array([transform.transform.translation.x,
                                                     transform.transform.translation.y,
                                                     transform.transform.translation.z])
        rospy.loginfo("Received DynaOb{} position: {}".format(index + 1, self.dynaob_positions[index]))

    def xform_callback(self, msg):
        for transform in msg.transforms:
            self.xform_pos = np.array([transform.transform.translation.x,
                                       transform.transform.translation.y,
                                       transform.transform.translation.z])
        rospy.loginfo("Received xform position: {}".format(self.xform_pos))

    def calculate_and_publish_force(self):
        if self.ot_centre1_pos is not None and self.cube1_pos is not None:
            # 计算当前距离
            distance = np.linalg.norm(self.cube1_pos - self.ot_centre1_pos)
            force_magnitude = self.calculate_force(distance)
            force_direction = -(self.ot_centre1_pos - self.cube1_pos) / distance
            raw_force = force_magnitude * force_direction
            
            # 计算虚拟阻尼力
            damping_force = self.calculate_damping_force(distance, force_direction)

            # 将虚拟阻尼力叠加到原力上
            total_force = raw_force + damping_force

            # 应用低通滤波器（EMA）
            self.filtered_force = self.alpha * total_force + (1 - self.alpha) * self.filtered_force
#
#
#
#
#
#
#
#
            # 创建并发布力反馈消息
            ratio = 0.0022
            feedback_msg = DeviceFeedback()
            feedback_msg.force.x = self.filtered_force[0] * ratio
            feedback_msg.force.y = self.filtered_force[1] * ratio
            feedback_msg.force.z = self.filtered_force[2] * ratio
            self.force_feedback_publisher.publish(feedback_msg)

    def calculate_force(self, distance):
        if distance < self.threshold_1:
            return -(self.angular_x * distance) 
        elif self.threshold_1 <= distance < self.threshold_2:
            return - (self.angular_y / (distance ** 2)) + self.linear_z
        else:
            return 0

    def calculate_damping_force(self, current_distance, force_direction):
        if self.previous_distance is not None and self.previous_time is not None:
            # 计算距离变化速度
            current_time = time.time()
            delta_time = current_time - self.previous_time
            distance_change_rate = (current_distance - self.previous_distance) / delta_time if delta_time > 0 else 0
            
            # 计算阻尼力（确保与计算力的方向相反）
            damping_force_magnitude = -self.damping_coefficient * distance_change_rate
            damping_force = damping_force_magnitude * force_direction

            # 更新距离和时间
            self.previous_distance = current_distance
            self.previous_time = current_time
            
            return damping_force
        else:
            # 初始化距离和时间
            self.previous_distance = current_distance
            self.previous_time = time.time()
            return np.array([0, 0, 0])
        

    def twist_callback(self, msg):
        new_linear = np.array([msg.linear.x, msg.linear.y, msg.linear.z])
        new_angular = np.array([msg.angular.x, msg.angular.y, msg.angular.z])
        self.filtered_linear = self.twist_alpha * new_linear + (1 - self.twist_alpha) * self.filtered_linear
        self.filtered_angular = self.twist_alpha * new_angular + (1 - self.twist_alpha) * self.filtered_angular
        smoothed_msg = Twist()
        smoothed_msg.linear.x = self.filtered_linear[0]
        smoothed_msg.linear.y = self.filtered_linear[1]
        smoothed_msg.linear.z = self.filtered_linear[2]
        smoothed_msg.angular.x = self.filtered_angular[0]
        smoothed_msg.angular.y = self.filtered_angular[1]
        smoothed_msg.angular.z = self.filtered_angular[2]
        self.smoothed_twist_publisher.publish(smoothed_msg)


if __name__ == '__main__':
    try:
        force_feedback_publisher = ForceFeedbackPublisher()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass
































'''
#!/usr/bin/env python
import rospy
import numpy as np
from std_msgs.msg import String
from geometry_msgs.msg import TransformStamped, PoseStamped, Twist
from sensor_msgs.msg import JointState
from tf2_msgs.msg import TFMessage
from geomagic_control.msg import DeviceFeedback


class ForceFeedbackPublisher:
    def __init__(self):
        rospy.init_node('force_feedback_publisher')
        
        # 订阅所需的主题
        self.tf_subscriber = rospy.Subscriber('/rtfotCentre2', TFMessage, self.ot_centre1_callback)
        self.cube1_subscriber = rospy.Subscriber('/rtfCube2', TFMessage, self.cube1_callback)
        self.force_field_subscriber = rospy.Subscriber('/OTForceFieldFromMatlab', Twist, self.force_field_callback)
        
        # 发布力反馈的主题
        self.force_feedback_publisher = rospy.Publisher('force_feedback', DeviceFeedback, queue_size=1)
        
        # 初始化变量
        self.ot_centre1_pos = None
        self.cube1_pos = None
        self.force_field_params = None

 
    def ot_centre1_callback(self, msg):
        # self.ot_centre1_pos = np.array([msg.transform.translation.x,
        #                                 msg.transform.translation.y,
        #                                 msg.transform.translation.z])
        for transform in msg.transforms:
            #self.ot_centre1_pos = transform.transform.translation
            self.ot_centre1_pos = np.array([transform.transform.translation.x,
                                            transform.transform.translation.y,
                                            transform.transform.translation.z])
        # self.ot_centre1_pos = msg.transforms.transform.translation
        # 添加输出语句
        rospy.loginfo("Received otCentre1 position: {}".format(self.ot_centre1_pos))
        self.calculate_and_publish_force()
 

    
    def force_field_callback(self, msg):
        self.force_field_params = msg
         # 添加输出语句
        rospy.loginfo("Received force field parameters: {}".format(self.force_field_params))
        
    def cube1_callback(self, msg):
        # self.cube1_pos = np.array([msg.transform.translation.x,
        #                            msg.transform.translation.y,
        #                            msg.transform.translation.z])
        for transform in msg.transforms:
            #self.cube1_pos = transform.transform.translation
            self.cube1_pos = np.array([transform.transform.translation.x,
                            transform.transform.translation.y,
                            transform.transform.translation.z])
        # 添加输出语句
        rospy.loginfo("Received Cube1 position: {}".format(self.cube1_pos))
        self.calculate_and_publish_force()

    def calculate_and_publish_force(self):
        if self.ot_centre1_pos is not None and self.cube1_pos is not None and self.force_field_params is not None:
            distance = np.linalg.norm(self.cube1_pos - self.ot_centre1_pos)
            force_magnitude = self.calculate_force(distance)
            force_direction = -(self.ot_centre1_pos - self.cube1_pos) / distance
            force = force_magnitude * force_direction
            
            # 创建并发布力反馈消息
            ratio=0.0001 #8月12日修改 原来是0.001
            feedback_msg = DeviceFeedback()
            feedback_msg.force.x = force[0]*ratio
            feedback_msg.force.y = force[1]*ratio
            feedback_msg.force.z = force[2]*ratio
            self.force_feedback_publisher.publish(feedback_msg)

    def calculate_force(self, distance):
        linear = self.force_field_params.linear
        angular = self.force_field_params.angular
        if distance < linear.x:
            return -(angular.x * distance)
        elif linear.x <= distance < linear.y * 0.22:
            return -(angular.y / (distance ** 2)) - linear.z
        else:
            return 0

if __name__ == '__main__':
    try:
        force_feedback_publisher = ForceFeedbackPublisher()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass


















#创建rate对象
# rate=rospy.Rate(1)
# while not rospy.is_shutdown():
#     pub.publish(feedback_msg)
#     rospy.loginfo("发布的消息:%.2f",feedback_msg.force.x)
#     rate.sleep()



# import rospy
# import numpy as np # type: ignore
# from geometry_msgs.msg import TransformStamped, Twist
# from tf2_msgs.msg import TFMessage
# from geomagic_control.msg import DeviceFeedback

# class ForceFeedbackPublisher:
#     def __init__(self):
#         rospy.init_node('force_feedback_publisher')
        
#         # 订阅所需的主题
#         self.tf_subscriber = rospy.Subscriber('/tf/otCentre1', TFMessage, self.tf_callback)
#         self.tf_subscriber = rospy.Subscriber('/tf/Cube1', TFMessage, self.tf_callback)
#         self.force_field_subscriber = rospy.Subscriber('/OTForceFieldFromMatlab', Twist, self.force_field_callback)
        
#         # 发布力反馈的主题
#         self.force_feedback_publisher = rospy.Publisher('force_feedback', DeviceFeedback, queue_size=1)
        
#         # 初始化变量
#         self.cube1_pos = None
#         self.ot_centre1_pos = None
#         self.force_field_params = None

#     def tf_callback(self, msg):
#         for transform in msg.transforms:
#             if transform.child_frame_id == "Cube1":
#                 self.cube1_pos = np.array([transform.transform.translation.x,
#                                            transform.transform.translation.y,
#                                            transform.transform.translation.z])
#             elif transform.child_frame_id == "otCentre1":
#                 self.ot_centre1_pos = np.array([transform.transform.translation.x,
#                                                 transform.transform.translation.y,
#                                                 transform.transform.translation.z])
#         self.calculate_and_publish_force()

#     def force_field_callback(self, msg):
#         self.force_field_params = msg

#     def calculate_and_publish_force(self):
#         if self.cube1_pos is not None and self.ot_centre1_pos is not None and self.force_field_params is not None:
#             distance = np.linalg.norm(self.cube1_pos - self.ot_centre1_pos)
#             force_magnitude = self.calculate_force(distance)
#             force_direction = (self.ot_centre1_pos - self.cube1_pos) / distance
#             force = force_magnitude * force_direction
            
#             # 创建并发布力反馈消息
#             feedback_msg = DeviceFeedback()
#             feedback_msg.force.x = force[0]
#             feedback_msg.force.y = force[1]
#             feedback_msg.force.z = force[2]
#             self.force_feedback_publisher.publish(feedback_msg)

#     def calculate_force(self, distance):
#         linear = self.force_field_params.linear
#         angular = self.force_field_params.angular
#         if distance < linear.x:
#             return -(angular.x * distance)
#         elif linear.x <= distance < linear.y * 0.22:
#             return -(angular.y / (distance ** 2)) - linear.z
#         else:
#             return 0

# if __name__ == '__main__':
#     try:
#         force_feedback_publisher = ForceFeedbackPublisher()
#         rospy.spin()
#     except rospy.ROSInterruptException:
#         pass

# import rospy
# import tf

# def tf_callback(msg):
#     for transform in msg.transforms:
#         if transform.child_frame_id == "otCentre1":
#             # 提取坐标系为"otCentre1"的变换信息
#             translation = transform.transform.translation
#             x = translation.x
#             y = translation.y
#             z = translation.z
#             rospy.loginfo("otCentre1 translation: x={}, y={}, z={}".format(x, y, z))

# def tf_listener():
#     rospy.init_node('tf_listener', anonymous=True)
#     rospy.Subscriber('/tf', tf.tfMessage, tf_callback)

# if __name__ == '__main__':
#     tf_listener()
#     rospy.spin()  # 可以删掉这一行，代码仍然可以正常运行
'''