#include <libum.h>
#include <iostream>

using namespace std;
#define LIBUM_DEF_BCAST_ADDRESS   "169.254.255.255"

#include <ros/ros.h>
#include "geometry_msgs/PoseStamped.h"

float current_x=0.0;
float current_y=0.0;
float current_z=0.0;
float current_d=0.0;


float last_x = 0, last_y = 0, last_z = 0;
bool first_message_received = false;
LibUm um;
void poseCallback(const geometry_msgs::PoseStamped::ConstPtr& msg) {

    // std::cout<< "get in!!!!!!!!!!!"<<std::endl;
    if (!first_message_received) {
        first_message_received = true;
    } else {
        float diff_x = msg->pose.position.z - last_z;
        float diff_y = msg->pose.position.x - last_x;
        float diff_z = msg->pose.position.y - last_y;

        // Apply a coefficient to the difference
        float coeff = 100; // Example coefficient
        diff_x *= coeff;
        diff_y *= coeff;
        diff_z *= coeff;
   
        // bool get_success = um.getPositions(current_x,current_y,current_z,current_d);
        // um.gotoPos(0,0,0,0,2000,0);
        // Command UM robot with the new position based on the difference
        // Assuming LibUm um; has been initialized

        // std::cout<<*current_x + diff_x<<std::endl;
        // current_x = current_x + diff_x;
        // current_y = current_y + diff_y;
        // current_z = current_z + diff_z;
        um.takeStep(diff_x,-diff_y,-diff_z,0,2000);
        // um.gotoPos(current_x, current_y, current_z, 0, 2000, 0,true);


    }

    // Update last pose
    last_x = msg->pose.position.x;
    last_y = msg->pose.position.y;
    last_z = msg->pose.position.z;
}

int main(int argc, char **argv)
{
    // Initialize the ROS node
    
    um.open(LIBUM_DEF_BCAST_ADDRESS, 20, 0);
    int num = um.getDeviceList();
    bool success = um.gotoPos(0,0,0,0,2000,0);
    std::cout<<num<<std::endl;
    ros::init(argc, argv, "ump_control");
    ros::NodeHandle n;
    
    // Create a subscriber to the pose topic
    ros::Subscriber pose_sub = n.subscribe("/Geomagic/pose", 1, poseCallback);
    
    // Spin to keep the callback function calling
    ros::spin();

    um.close();

    return 0;
}






