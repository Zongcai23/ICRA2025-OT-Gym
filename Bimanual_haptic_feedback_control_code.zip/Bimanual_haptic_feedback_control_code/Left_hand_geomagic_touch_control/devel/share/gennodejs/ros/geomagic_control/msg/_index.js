
"use strict";

let DeviceButtonEvent = require('./DeviceButtonEvent.js');
let DeviceFeedback = require('./DeviceFeedback.js');

module.exports = {
  DeviceButtonEvent: DeviceButtonEvent,
  DeviceFeedback: DeviceFeedback,
};
