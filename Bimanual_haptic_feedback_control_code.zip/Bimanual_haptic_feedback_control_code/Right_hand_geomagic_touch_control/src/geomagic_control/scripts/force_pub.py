
#!/usr/bin/env python
#!/usr/bin/env python

#!/usr/bin/env python

#!/usr/bin/env python
#!/usr/bin/env python
#!/usr/bin/env python
import rospy
import numpy as np
import time
from geometry_msgs.msg import Twist
from tf2_msgs.msg import TFMessage
from geomagic_control.msg import DeviceFeedback
#from geometry_msgs.msg import Twist
from geomagic_control.msg import DeviceButtonEvent
#from geomagic_control.msg import DeviceButtonEvent



class ForceFeedbackPublisher:
    def __init__(self):
        rospy.init_node('force_feedback_publisher')
        
        # 设定阈值和参数
        self.threshold_1 = 0.08
        self.threshold_2 = 0.1
        self.angular_x = -12000
        self.angular_y = -16.18 #原来是-25
        self.linear_z = -1568   #原来是-2450

        # 虚拟阻尼和滤波参数
        self.damping_coefficient = -0  # 阻尼系数
        self.alpha = 0.05  # 低通滤波系数，0 < alpha < 1 原来是0.2

        # 存储距离和时间，用于计算距离变化速度
        self.previous_distance = None
        self.previous_time = None

        # 初始化低通滤波后的力
        self.filtered_force = np.array([0.0, 0.0, 0.0])

        # 初始化human_weight
        self.human_weight = np.array([0.0, 0.0, 0.0])

        # 订阅所需的主题
        self.ot_subscriber = rospy.Subscriber('/firstOTposition', TFMessage, self.ot_centre1_callback)
        self.cube1_subscriber = rospy.Subscriber('/robot01', TFMessage, self.cube1_callback)
        self.dynaob_subscribers = [
            rospy.Subscriber('/DynaOb01', TFMessage, self.dynaob_callback, callback_args=0),
            rospy.Subscriber('/DynaOb02', TFMessage, self.dynaob_callback, callback_args=1),
            rospy.Subscriber('/DynaOb03', TFMessage, self.dynaob_callback, callback_args=2),
            rospy.Subscriber('/DynaOb04', TFMessage, self.dynaob_callback, callback_args=3)
        ]
        self.xform_subscriber = rospy.Subscriber('/xform', TFMessage, self.xform_callback)
        self.button_subscriber = rospy.Subscriber('/Geomagic/button', DeviceButtonEvent, self.button_callback)
        #self.button_subscriber = rospy.Subscriber('/Geomagic/button', DeviceButtonEvent, self.button_callback)


        
    
        
        ################
        # 设定阈值和参数
        self.twist_alpha = 0.05  # 为 Twist 过滤设置的滤波系数，避免与原有变量冲突,原来是0.2
        self.filtered_linear = np.array([0.0, 0.0, 0.0])
        self.filtered_angular = np.array([0.0, 0.0, 0.0])

        # 订阅 /Geomagic/twist 主题
        self.twist_subscriber = rospy.Subscriber('/Geomagic/twist', Twist, self.twist_callback)
        self.smoothed_twist_publisher = rospy.Publisher('/Geomagic/smoothedTwist', Twist, queue_size=1)
        
        
        
        # 发布力反馈和human_weight的主题
        self.force_feedback_publisher = rospy.Publisher('force_feedback', DeviceFeedback, queue_size=1)
        self.human_weight_publisher = rospy.Publisher('/humanWeight', Twist, queue_size=1)
        self.button_twist_publisher = rospy.Publisher('buttonHelper', Twist, queue_size=1)
        #self.grey_button = 0
        #self.white_button = 0

        # 初始化变量
        self.ot_centre1_pos = None
        self.cube1_pos = None
        self.dynaob_positions = [None] * 4
        self.xform_pos = None
        

    
    def publish_twist_based_on_button(self):
        twist_msg = Twist()
        if self.grey_button == 1 or self.white_button == 1:
            twist_msg.angular.x = 1
        else:
            twist_msg.angular.x = 0
        #rospy.loginfo("Publishing Twist message: angular.x={}".format(twist_msg.angular.x))
        self.button_twist_publisher.publish(twist_msg)
        

    
    def button_callback(self, msg):
        self.grey_button = msg.grey_button
        self.white_button = msg.white_button
        #rospy.loginfo("Button callback triggered: grey_button={}, white_button={}".format(self.grey_button, self.white_button))
        self.publish_twist_based_on_button()


    def ot_centre1_callback(self, msg):
        for transform in msg.transforms:
            self.ot_centre1_pos = np.array([transform.transform.translation.x,
                                            transform.transform.translation.y,
                                            transform.transform.translation.z])
        #rospy.loginfo("Received otCentre1 position: {}".format(self.ot_centre1_pos))
        self.calculate_and_publish_force()
        
    def twist_callback(self, msg):
        new_linear = np.array([msg.linear.x, msg.linear.y, msg.linear.z])
        new_angular = np.array([msg.angular.x, msg.angular.y, msg.angular.z])
        self.filtered_linear = self.twist_alpha * new_linear + (1 - self.twist_alpha) * self.filtered_linear
        self.filtered_angular = self.twist_alpha * new_angular + (1 - self.twist_alpha) * self.filtered_angular
        smoothed_msg = Twist()
        smoothed_msg.linear.x = self.filtered_linear[0]
        smoothed_msg.linear.y = self.filtered_linear[1]
        smoothed_msg.linear.z = self.filtered_linear[2]
        smoothed_msg.angular.x = self.filtered_angular[0]
        smoothed_msg.angular.y = self.filtered_angular[1]
        smoothed_msg.angular.z = self.filtered_angular[2]
        self.smoothed_twist_publisher.publish(smoothed_msg)

    def cube1_callback(self, msg):
        for transform in msg.transforms:
            self.cube1_pos = np.array([transform.transform.translation.x,
                                       transform.transform.translation.y,
                                       transform.transform.translation.z])
        #rospy.loginfo("Received Cube1 position: {}".format(self.cube1_pos))
        self.calculate_and_publish_force()

    def dynaob_callback(self, msg, index):
        for transform in msg.transforms:
            self.dynaob_positions[index] = np.array([transform.transform.translation.x,
                                                     transform.transform.translation.y,
                                                     transform.transform.translation.z])
        #rospy.loginfo("Received DynaOb{} position: {}".format(index + 1, self.dynaob_positions[index]))
        self.calculate_human_weight()

    def xform_callback(self, msg):
        for transform in msg.transforms:
            self.xform_pos = np.array([transform.transform.translation.x,
                                       transform.transform.translation.y,
                                       transform.transform.translation.z])
        #rospy.loginfo("Received xform position: {}".format(self.xform_pos))
        self.calculate_human_weight()

    def calculate_human_weight(self):
        #if self.xform_pos is not None and all(pos is not None for pos in self.dynaob_positions):
            #distances = [np.linalg.norm(self.xform_pos - pos) for pos in self.dynaob_positions]
            #distances.append(np.linalg.norm(self.xform_pos - np.array([2, -15, 0.5])))
        if self.xform_pos is not None and all(pos is not None for pos in self.dynaob_positions):
        # 计算所有目标点与 xform_pos 之间的距离
            distances = [np.linalg.norm(self.xform_pos - pos) for pos in self.dynaob_positions]
            reference_distance = np.linalg.norm(self.xform_pos - np.array([2, -15, 0.7]))
            distances.append(reference_distance)
            # 初始化权重因子和linear.x的值
            control_value = 0
            noise_value = 3
            
            if reference_distance <=0.01:
                noise_value =  50
            else:
                noise_value =  3
#
            # 判断与参考点 (2, -15, 0.5) 的距离，如果大于 0.5 则调整 human weight
            if reference_distance >= 0.5:
                adjust_weight = True
            else:
                adjust_weight = False
#
#
#
            if any(d < 0.7 for d in distances):   #原来是<0.6
                self.human_weight = np.array([0.0003, 0.0003, 0]) #原来是0.0005
                control_value = 2  # 如果距离小于0.6，linear.x发送2
            elif any(0.7 <= d < 1.2 for d in distances): #原来是<1.5
                self.human_weight = np.array([0.0002, 0.0002, 0]) #原来是0.0002
                control_value = 1  # 如果距离在0.6到1之间，linear.x发送1
            else:
                self.human_weight = np.array([0.00005, 0.00005, 0]) #原来是0.0001
                control_value = 0  # 如果距离大于等于1，linear.x发送0
                
                
            # 如果距离参考点大于 0.5，则将第二项乘以 0.2
            if adjust_weight:
                self.human_weight[0] *= 0.2

            # 构建并发布 Twist 消息
            twist_msg = Twist()
            twist_msg.angular.x = self.human_weight[0]
            twist_msg.angular.y = self.human_weight[1]
            twist_msg.angular.z = self.human_weight[2]
            twist_msg.linear.x = control_value  # 发送控制值
            twist_msg.linear.y = noise_value  # 发送控制值

            self.human_weight_publisher.publish(twist_msg)

    def calculate_and_publish_force(self):
        if self.ot_centre1_pos is not None and self.cube1_pos is not None:
            # 计算当前距离
            distance = np.linalg.norm(self.cube1_pos - self.ot_centre1_pos)
            force_magnitude = self.calculate_force(distance)
            force_direction = -(self.ot_centre1_pos - self.cube1_pos) / distance
            raw_force = force_magnitude * force_direction
            
            # 计算虚拟阻尼力
            damping_force = self.calculate_damping_force(distance, force_direction)

            # 将虚拟阻尼力叠加到原力上
            total_force = raw_force + damping_force

            # 应用低通滤波器（EMA）
            self.filtered_force = self.alpha * total_force + (1 - self.alpha) * self.filtered_force
#
#
#
#
###############################
            # 创建并发布力反馈消息
            ratio = 0.0030 #原来是0.0022 0.0018不错
            feedback_msg = DeviceFeedback()
            feedback_msg.force.x = self.filtered_force[0] * ratio
            feedback_msg.force.y = self.filtered_force[1] * ratio
            feedback_msg.force.z = self.filtered_force[2] * ratio
            self.force_feedback_publisher.publish(feedback_msg)

    def calculate_force(self, distance):
        if distance < self.threshold_1:
            return -(self.angular_x * distance)  
        elif self.threshold_1 <= distance < self.threshold_2:
            return - (self.angular_y / (distance ** 2)) + self.linear_z
        else:
            return 0

    def calculate_damping_force(self, current_distance, force_direction):
        if self.previous_distance is not None and self.previous_time is not None:
            # 计算距离变化速度
            current_time = time.time()
            delta_time = current_time - self.previous_time
            distance_change_rate = (current_distance - self.previous_distance) / delta_time if delta_time > 0 else 0
            
            # 计算阻尼力（确保与计算力的方向相反）
            damping_force_magnitude = -self.damping_coefficient * distance_change_rate
            damping_force = damping_force_magnitude * force_direction

            # 更新距离和时间
            self.previous_distance = current_distance
            self.previous_time = current_time
            
            return damping_force
        else:
            # 初始化距离和时间
            self.previous_distance = current_distance
            self.previous_time = time.time()
            return np.array([0, 0, 0])

if __name__ == '__main__':
    try:
        force_feedback_publisher = ForceFeedbackPublisher()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass
    
 











'''
import rospy
import numpy as np
import time
from geometry_msgs.msg import Twist
from tf2_msgs.msg import TFMessage
from geomagic_control.msg import DeviceFeedback

class ForceFeedbackPublisher:
    def __init__(self):
        rospy.init_node('force_feedback_publisher')
        
        # 设定阈值和参数
        self.threshold_1 = 0.08
        self.threshold_2 = 0.1
        self.angular_x = -12000
        self.angular_y = -25
        self.linear_z = -2450

        # 虚拟阻尼和滤波参数
        self.damping_coefficient = 0  # 阻尼系数
        self.alpha = 0.3  # 低通滤波系数，0 < alpha < 1

        # 存储距离和时间，用于计算距离变化速度
        self.previous_distance = None
        self.previous_time = None

        # 初始化低通滤波后的力
        self.filtered_force = np.array([0.0, 0.0, 0.0])

        # 订阅所需的主题
        self.ot_subscriber = rospy.Subscriber('/firstOTposition', TFMessage, self.ot_centre1_callback)
        self.cube1_subscriber = rospy.Subscriber('/robot01', TFMessage, self.cube1_callback)
        
        # 发布力反馈的主题
        self.force_feedback_publisher = rospy.Publisher('force_feedback', DeviceFeedback, queue_size=1)
        
        # 初始化变量
        self.ot_centre1_pos = None
        self.cube1_pos = None

    def ot_centre1_callback(self, msg):
        for transform in msg.transforms:
            self.ot_centre1_pos = np.array([transform.transform.translation.x,
                                            transform.transform.translation.y,
                                            transform.transform.translation.z])
        rospy.loginfo("Received otCentre1 position: {}".format(self.ot_centre1_pos))
        self.calculate_and_publish_force()

    def cube1_callback(self, msg):
        for transform in msg.transforms:
            self.cube1_pos = np.array([transform.transform.translation.x,
                                       transform.transform.translation.y,
                                       transform.transform.translation.z])
        rospy.loginfo("Received Cube1 position: {}".format(self.cube1_pos))
        self.calculate_and_publish_force()

    def calculate_and_publish_force(self):
        if self.ot_centre1_pos is not None and self.cube1_pos is not None:
            # 计算当前距离
            distance = np.linalg.norm(self.cube1_pos - self.ot_centre1_pos)
            force_magnitude = self.calculate_force(distance)
            #
            #
            #
            #
            #
            #
            #
            force_direction = -(self.ot_centre1_pos - self.cube1_pos) / distance
            raw_force = force_magnitude * force_direction
            
            # 计算虚拟阻尼力
            damping_force = self.calculate_damping_force(distance, force_direction)

            # 将虚拟阻尼力叠加到原力上
            total_force = raw_force + damping_force

            # 应用低通滤波器（EMA）
            self.filtered_force = self.alpha * total_force + (1 - self.alpha) * self.filtered_force

            # 创建并发布力反馈消息
            ratio = 0.0027
            feedback_msg = DeviceFeedback()
            feedback_msg.force.x = self.filtered_force[0] * ratio
            feedback_msg.force.y = self.filtered_force[1] * ratio
            feedback_msg.force.z = self.filtered_force[2] * ratio
            self.force_feedback_publisher.publish(feedback_msg)

    def calculate_force(self, distance):
        if distance < self.threshold_1:
            return -(self.angular_x * distance) + 500
        elif self.threshold_1 <= distance < self.threshold_2:
            return - (self.angular_y / (distance ** 2)) + self.linear_z
        else:
            return 0

    def calculate_damping_force(self, current_distance, force_direction):
        if self.previous_distance is not None and self.previous_time is not None:
            # 计算距离变化速度
            current_time = time.time()
            delta_time = current_time - self.previous_time
            distance_change_rate = (current_distance - self.previous_distance) / delta_time if delta_time > 0 else 0
            
            # 计算阻尼力（确保与计算力的方向相反）
            damping_force_magnitude = -self.damping_coefficient * distance_change_rate
            damping_force = damping_force_magnitude * force_direction

            # 更新距离和时间
            self.previous_distance = current_distance
            self.previous_time = current_time
            
            return damping_force
        else:
            # 初始化距离和时间
            self.previous_distance = current_distance
            self.previous_time = time.time()
            return np.array([0, 0, 0])

if __name__ == '__main__':
    try:
        force_feedback_publisher = ForceFeedbackPublisher()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass
'''












'''
import rospy
import numpy as np
from std_msgs.msg import String
from geometry_msgs.msg import TransformStamped, PoseStamped, Twist
from sensor_msgs.msg import JointState
from tf2_msgs.msg import TFMessage
from geomagic_control.msg import DeviceFeedback
import time

class ForceFeedbackPublisher:
    def __init__(self):
        rospy.init_node('force_feedback_publisher')
        
        # 设定阈值和参数
        self.threshold_1 = 0.08
        self.threshold_2 = 0.1
        self.angular_x = -12000
        self.angular_y = -25
        self.linear_z = -2450
        self.damping_coefficient = 50  # 阻尼系数

        # 存储位置和时间，用于计算速度
        self.previous_position = None
        self.previous_time = None

        # 订阅所需的主题
        self.ot_subscriber = rospy.Subscriber('/firstOTposition', TFMessage, self.ot_centre1_callback)
        self.cube1_subscriber = rospy.Subscriber('/robot01', TFMessage, self.cube1_callback)
        self.dynaob_subscribers = [
            rospy.Subscriber('/DynaOb01', TFMessage, self.dynaob_callback, callback_args=0),
            rospy.Subscriber('/DynaOb02', TFMessage, self.dynaob_callback, callback_args=1),
            rospy.Subscriber('/DynaOb03', TFMessage, self.dynaob_callback, callback_args=2),
            rospy.Subscriber('/DynaOb04', TFMessage, self.dynaob_callback, callback_args=3)
        ]
        self.xform_subscriber = rospy.Subscriber('/xform', TFMessage, self.xform_callback)
        
        # 发布力反馈和human_weight的主题
        self.force_feedback_publisher = rospy.Publisher('force_feedback', DeviceFeedback, queue_size=1)
        self.human_weight_publisher = rospy.Publisher('/humanWeight', Twist, queue_size=1)
        
        # 初始化变量
        self.ot_centre1_pos = None
        self.cube1_pos = None
        self.dynaob_positions = [None] * 4
        self.xform_pos = None
 
    def ot_centre1_callback(self, msg):
        for transform in msg.transforms:
            self.ot_centre1_pos = np.array([transform.transform.translation.x,
                                            transform.transform.translation.y,
                                            transform.transform.translation.z])
        rospy.loginfo("Received otCentre1 position: {}".format(self.ot_centre1_pos))
        self.calculate_and_publish_force()

    def cube1_callback(self, msg):
        for transform in msg.transforms:
            self.cube1_pos = np.array([transform.transform.translation.x,
                                       transform.transform.translation.y,
                                       transform.transform.translation.z])
        rospy.loginfo("Received Cube1 position: {}".format(self.cube1_pos))
        self.calculate_and_publish_force()

    def dynaob_callback(self, msg, index):
        for transform in msg.transforms:
            self.dynaob_positions[index] = np.array([transform.transform.translation.x,
                                                     transform.transform.translation.y,
                                                     transform.transform.translation.z])
        rospy.loginfo("Received DynaOb{} position: {}".format(index+1, self.dynaob_positions[index]))
        self.calculate_human_weight()

    def xform_callback(self, msg):
        for transform in msg.transforms:
            self.xform_pos = np.array([transform.transform.translation.x,
                                       transform.transform.translation.y,
                                       transform.transform.translation.z])
        rospy.loginfo("Received xform position: {}".format(self.xform_pos))
        self.calculate_human_weight()

    def calculate_human_weight(self):
        if self.xform_pos is not None and all(pos is not None for pos in self.dynaob_positions):
            distances = [np.linalg.norm(self.xform_pos - pos) for pos in self.dynaob_positions]
            distances.append(np.linalg.norm(self.xform_pos - np.array([2, -15, 0.5])))

            if any(d < 0.6 for d in distances):
                human_weight = np.array([0.00005, 0.00005, 0])
            elif any(0.6 <= d < 1 for d in distances):
                human_weight = np.array([0.000025, 0.000025, 0])
            else:
                human_weight = np.array([0.00001, 0.00001, 0])

            twist_msg = Twist()
            twist_msg.angular.x = human_weight[0]
            twist_msg.angular.y = human_weight[1]
            twist_msg.angular.z = human_weight[2]

            self.human_weight_publisher.publish(twist_msg)

    def calculate_and_publish_force(self):
        if self.ot_centre1_pos is not None and self.cube1_pos is not None:
            distance = np.linalg.norm(self.cube1_pos - self.ot_centre1_pos)
            force_magnitude = self.calculate_force(distance)
            force_direction = -(self.ot_centre1_pos - self.cube1_pos) / distance
            force = force_magnitude * force_direction
            
            # 计算阻尼力
            damping_force = self.calculate_damping_force(force)

            # 将阻尼力叠加到原力上
            total_force = force + damping_force

            # 创建并发布力反馈消息
            ratio = 0.002
            feedback_msg = DeviceFeedback()
            feedback_msg.force.x = total_force[0] * ratio
            feedback_msg.force.y = total_force[1] * ratio
            feedback_msg.force.z = total_force[2] * ratio
            self.force_feedback_publisher.publish(feedback_msg)

    def calculate_force(self, distance):
        if distance < self.threshold_1:
            return -(self.angular_x * distance) + 500
        elif self.threshold_1 <= distance < self.threshold_2:
            return - (self.angular_y / (distance ** 2)) + self.linear_z
        else:
            return 0

    def calculate_damping_force(self, force):
        if self.previous_position is not None and self.previous_time is not None:
            # 计算当前位置与之前位置的速度
            current_time = time.time()
            delta_time = current_time - self.previous_time
            velocity = (self.cube1_pos - self.previous_position) / delta_time if delta_time > 0 else 0
            
            # 计算阻尼力
            damping_force = -self.damping_coefficient * velocity
            
            # 更新位置和时间
            self.previous_position = self.cube1_pos
            self.previous_time = current_time
            
            return damping_force
        else:
            # 初始化位置和时间
            self.previous_position = self.cube1_pos
            self.previous_time = time.time()
            return np.array([0, 0, 0])

if __name__ == '__main__':
    try:
        force_feedback_publisher = ForceFeedbackPublisher()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass
'''








'''
import rospy
import numpy as np
from std_msgs.msg import String
from geometry_msgs.msg import TransformStamped, PoseStamped, Twist
from sensor_msgs.msg import JointState
from tf2_msgs.msg import TFMessage
from geomagic_control.msg import DeviceFeedback

class ForceFeedbackPublisher:
    def __init__(self):
        rospy.init_node('force_feedback_publisher')
        
        # 设定阈值和参数
        self.threshold_1 = 0.08
        self.threshold_2 = 0.1
        self.angular_x = -12000
        self.angular_y = -25
        self.linear_z = -2450

        # 订阅所需的主题
        self.ot_subscriber = rospy.Subscriber('/firstOTposition', TFMessage, self.ot_centre1_callback)
        self.cube1_subscriber = rospy.Subscriber('/robot01', TFMessage, self.cube1_callback)
        self.dynaob_subscribers = [
            rospy.Subscriber('/DynaOb01', TFMessage, self.dynaob_callback, callback_args=0),
            rospy.Subscriber('/DynaOb02', TFMessage, self.dynaob_callback, callback_args=1),
            rospy.Subscriber('/DynaOb03', TFMessage, self.dynaob_callback, callback_args=2),
            rospy.Subscriber('/DynaOb04', TFMessage, self.dynaob_callback, callback_args=3)
        ]
        self.xform_subscriber = rospy.Subscriber('/xform', TFMessage, self.xform_callback)
        
        # 发布力反馈和human_weight的主题
        self.force_feedback_publisher = rospy.Publisher('force_feedback', DeviceFeedback, queue_size=1)
        self.human_weight_publisher = rospy.Publisher('/humanWeight', Twist, queue_size=1)
        
        # 初始化变量
        self.ot_centre1_pos = None
        self.cube1_pos = None
        self.dynaob_positions = [None] * 4
        self.xform_pos = None
 
    def ot_centre1_callback(self, msg):
        for transform in msg.transforms:
            self.ot_centre1_pos = np.array([transform.transform.translation.x,
                                            transform.transform.translation.y,
                                            transform.transform.translation.z])
        rospy.loginfo("Received otCentre1 position: {}".format(self.ot_centre1_pos))
        self.calculate_and_publish_force()

    def cube1_callback(self, msg):
        for transform in msg.transforms:
            self.cube1_pos = np.array([transform.transform.translation.x,
                                       transform.transform.translation.y,
                                       transform.transform.translation.z])
        rospy.loginfo("Received Cube1 position: {}".format(self.cube1_pos))
        self.calculate_and_publish_force()

    def dynaob_callback(self, msg, index):
        for transform in msg.transforms:
            self.dynaob_positions[index] = np.array([transform.transform.translation.x,
                                                     transform.transform.translation.y,
                                                     transform.transform.translation.z])
        rospy.loginfo("Received DynaOb{} position: {}".format(index+1, self.dynaob_positions[index]))
        self.calculate_human_weight()

    def xform_callback(self, msg):
        for transform in msg.transforms:
            self.xform_pos = np.array([transform.transform.translation.x,
                                       transform.transform.translation.y,
                                       transform.transform.translation.z])
        rospy.loginfo("Received xform position: {}".format(self.xform_pos))
        self.calculate_human_weight()

    def calculate_human_weight(self):
        if self.xform_pos is not None and all(pos is not None for pos in self.dynaob_positions):
            distances = [np.linalg.norm(self.xform_pos - pos) for pos in self.dynaob_positions]
            distances.append(np.linalg.norm(self.xform_pos - np.array([2, -15, 0.5])))

            if any(d < 0.6 for d in distances):
                human_weight = np.array([0.00005, 0.00005, 0])
            elif any(0.6 <= d < 1 for d in distances):
                human_weight = np.array([0.000025, 0.000025, 0])
            else:
                human_weight = np.array([0.00001, 0.00001, 0])

            twist_msg = Twist()
            twist_msg.angular.x = human_weight[0]
            twist_msg.angular.y = human_weight[1]
            twist_msg.angular.z = human_weight[2]

            self.human_weight_publisher.publish(twist_msg)

    def calculate_and_publish_force(self):
        if self.ot_centre1_pos is not None and self.cube1_pos is not None:
            distance = np.linalg.norm(self.cube1_pos - self.ot_centre1_pos)
            force_magnitude = self.calculate_force(distance)
            force_direction = -(self.ot_centre1_pos - self.cube1_pos) / distance
            force = force_magnitude * force_direction
            
            # 创建并发布力反馈消息
            ratio = 0.002
            feedback_msg = DeviceFeedback()
            feedback_msg.force.x = force[0] * ratio
            feedback_msg.force.y = force[1] * ratio
            feedback_msg.force.z = force[2] * ratio
            self.force_feedback_publisher.publish(feedback_msg)

    def calculate_force(self, distance):
        if distance < self.threshold_1:
            return -(self.angular_x * distance) + 500
        elif self.threshold_1 <= distance < self.threshold_2:
            return - (self.angular_y / (distance ** 2)) + self.linear_z
        else:
            return 0

if __name__ == '__main__':
    try:
        force_feedback_publisher = ForceFeedbackPublisher()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass
'''








'''
import rospy
import numpy as np
from std_msgs.msg import String
from geometry_msgs.msg import TransformStamped, PoseStamped, Twist
from sensor_msgs.msg import JointState
from tf2_msgs.msg import TFMessage
from geomagic_control.msg import DeviceFeedback

class ForceFeedbackPublisher:
    def __init__(self):
        rospy.init_node('force_feedback_publisher')
        
        # 订阅所需的主题
        self.ot_subscriber = rospy.Subscriber('/firstOTposition', TFMessage, self.ot_centre1_callback)
        self.cube1_subscriber = rospy.Subscriber('/robot01', TFMessage, self.cube1_callback)
        self.dynaob_subscribers = [
            rospy.Subscriber('/DynaOb01', TFMessage, self.dynaob_callback, callback_args=0),
            rospy.Subscriber('/DynaOb02', TFMessage, self.dynaob_callback, callback_args=1),
            rospy.Subscriber('/DynaOb03', TFMessage, self.dynaob_callback, callback_args=2),
            rospy.Subscriber('/DynaOb04', TFMessage, self.dynaob_callback, callback_args=3)
        ]
        self.xform_subscriber = rospy.Subscriber('/xform', TFMessage, self.xform_callback)
        self.force_field_subscriber = rospy.Subscriber('/OTForceFieldFromMatlab', Twist, self.force_field_callback)
        
        # 发布力反馈和human_weight的主题
        self.force_feedback_publisher = rospy.Publisher('force_feedback', DeviceFeedback, queue_size=1)
        self.human_weight_publisher = rospy.Publisher('/humanWeight', Twist, queue_size=1)
        
        # 初始化变量
        self.ot_centre1_pos = None
        self.cube1_pos = None
        self.force_field_params = None
        self.dynaob_positions = [None] * 4
        self.xform_pos = None
 
    def ot_centre1_callback(self, msg):
        for transform in msg.transforms:
            self.ot_centre1_pos = np.array([transform.transform.translation.x,
                                            transform.transform.translation.y,
                                            transform.transform.translation.z])
        rospy.loginfo("Received otCentre1 position: {}".format(self.ot_centre1_pos))
        self.calculate_and_publish_force()

    def force_field_callback(self, msg):
        self.force_field_params = msg
        rospy.loginfo("Received force field parameters: {}".format(self.force_field_params))
        
    def cube1_callback(self, msg):
        for transform in msg.transforms:
            self.cube1_pos = np.array([transform.transform.translation.x,
                                       transform.transform.translation.y,
                                       transform.transform.translation.z])
        rospy.loginfo("Received Cube1 position: {}".format(self.cube1_pos))
        self.calculate_and_publish_force()

    def dynaob_callback(self, msg, index):
        for transform in msg.transforms:
            self.dynaob_positions[index] = np.array([transform.transform.translation.x,
                                                     transform.transform.translation.y,
                                                     transform.transform.translation.z])
        rospy.loginfo("Received DynaOb{} position: {}".format(index+1, self.dynaob_positions[index]))
        self.calculate_human_weight()

    def xform_callback(self, msg):
        for transform in msg.transforms:
            self.xform_pos = np.array([transform.transform.translation.x,
                                       transform.transform.translation.y,
                                       transform.transform.translation.z])
        rospy.loginfo("Received xform position: {}".format(self.xform_pos))
        self.calculate_human_weight()

    def calculate_human_weight(self):
        if self.xform_pos is not None and all(pos is not None for pos in self.dynaob_positions):
            distances = [np.linalg.norm(self.xform_pos - pos) for pos in self.dynaob_positions]
            distances.append(np.linalg.norm(self.xform_pos - np.array([2, -15, 0.5])))

            if any(d < 0.6 for d in distances):
                human_weight = np.array([0.1, 0.1, 0])
            elif any(0.6 <= d < 1 for d in distances):
                human_weight = np.array([0.05, 0.05, 0])
            else:
                human_weight = np.array([0.02, 0.02, 0])

            twist_msg = Twist()
            twist_msg.angular.x = human_weight[0]
            twist_msg.angular.y = human_weight[1]
            twist_msg.angular.z = human_weight[2]

            self.human_weight_publisher.publish(twist_msg)

    def calculate_and_publish_force(self):
        if self.ot_centre1_pos is not None and self.cube1_pos is not None and self.force_field_params is not None:
            distance = np.linalg.norm(self.cube1_pos - self.ot_centre1_pos)
            force_magnitude = self.calculate_force(distance)
            force_direction = -(self.ot_centre1_pos - self.cube1_pos) / distance
            force = force_magnitude * force_direction
            
            # 创建并发布力反馈消息
            ratio = 0.0001
            feedback_msg = DeviceFeedback()
            feedback_msg.force.x = force[0] * ratio
            feedback_msg.force.y = force[1] * ratio
            feedback_msg.force.z = force[2] * ratio
            self.force_feedback_publisher.publish(feedback_msg)

    def calculate_force(self, distance):
        linear = self.force_field_params.linear
        angular = self.force_field_params.angular
        if distance < linear.x:
            return -(angular.x * distance)
        elif linear.x <= distance < linear.y * 0.22:
            return -(angular.y / (distance ** 2)) - linear.z
        else:
            return 0

if __name__ == '__main__':
    try:
        force_feedback_publisher = ForceFeedbackPublisher()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass
'''




'''
import rospy
import numpy as np
from std_msgs.msg import String
from geometry_msgs.msg import TransformStamped, PoseStamped, Twist
from sensor_msgs.msg import JointState
from tf2_msgs.msg import TFMessage
from geomagic_control.msg import DeviceFeedback
 

class ForceFeedbackPublisher:
    def __init__(self):
        rospy.init_node('force_feedback_publisher')
        
        # 订阅所需的主题
        self.tf_subscriber = rospy.Subscriber('/rtfotCentre1', TFMessage, self.ot_centre1_callback)
        self.cube1_subscriber = rospy.Subscriber('/rtfCube1', TFMessage, self.cube1_callback)
        self.force_field_subscriber = rospy.Subscriber('/OTForceFieldFromMatlab', Twist, self.force_field_callback)
        
        # 发布力反馈的主题
        self.force_feedback_publisher = rospy.Publisher('force_feedback', DeviceFeedback, queue_size=1)
        
        # 初始化变量
        self.ot_centre1_pos = None
        self.cube1_pos = None
        self.force_field_params = None
 
            
    def ot_centre1_callback(self, msg):
 
        for transform in msg.transforms:
 
            self.ot_centre1_pos = np.array([transform.transform.translation.x,
                                            transform.transform.translation.y,
                                            transform.transform.translation.z])
 
        rospy.loginfo("Received otCentre1 position: {}".format(self.ot_centre1_pos))
        self.calculate_and_publish_force()
 
    
    def force_field_callback(self, msg):
        self.force_field_params = msg
         # 添加输出语句
        rospy.loginfo("Received force field parameters: {}".format(self.force_field_params))
        
    def cube1_callback(self, msg):
 
        for transform in msg.transforms:
 
            self.cube1_pos = np.array([transform.transform.translation.x,
                            transform.transform.translation.y,
                            transform.transform.translation.z])
        # 添加输出语句
        rospy.loginfo("Received Cube1 position: {}".format(self.cube1_pos))
        self.calculate_and_publish_force()

    def calculate_and_publish_force(self):
        if self.ot_centre1_pos is not None and self.cube1_pos is not None and self.force_field_params is not None:
            distance = np.linalg.norm(self.cube1_pos - self.ot_centre1_pos)
            force_magnitude = self.calculate_force(distance)
            force_direction = -(self.ot_centre1_pos - self.cube1_pos) / distance
            force = force_magnitude * force_direction
            
            # 创建并发布力反馈消息
            ratio=0.0001 #8月12日修改 原来是0.001
            feedback_msg = DeviceFeedback()
            feedback_msg.force.x = force[0]*ratio
            feedback_msg.force.y = force[1]*ratio
            feedback_msg.force.z = force[2]*ratio
            self.force_feedback_publisher.publish(feedback_msg)

    def calculate_force(self, distance):
        linear = self.force_field_params.linear
        angular = self.force_field_params.angular
        if distance < linear.x:
            return -(angular.x * distance)
        elif linear.x <= distance < linear.y * 0.22:
            return -(angular.y / (distance ** 2)) - linear.z
        else:
            return 0

if __name__ == '__main__':
    try:
        force_feedback_publisher = ForceFeedbackPublisher()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass
'''